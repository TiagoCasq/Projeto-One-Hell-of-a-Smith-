
// Text init
document.getElementById("Difficulty").textContent = "Current HP: " + CurrentDifficulty
document.getElementById("Electrum").textContent = "Electrum: " + Electrum
document.getElementById("Souls").textContent = "Souls: " + Souls

document.getElementById("HammerStats").textContent = ClickStrength + " Hammer Power"
document.getElementById("Energy").textContent = "Current Energy: " + Energy

// Update marquee
function NewsBoard(){

    let Position = Math.floor(Math.random() * (News.length - 1 + 1)) 

    document.getElementById("NoticeBoard").textContent = News[Position]

}
NewsBoard()
setInterval(NewsBoard, 5500)


// Update UI Functions
function UpdateCurrency(){

    document.getElementById("Electrum").textContent = "Electrum: " + Electrum
    document.getElementById("Souls").textContent = "Souls: " + Souls
    document.getElementById("Energy").textContent = "Current Energy: " + Energy
}

function UpdateStats(){

    document.getElementById("HammerStats").textContent = ClickStrength + " Hammer Power";

}

function UpdateDifficulty(){
    document.getElementById("Difficulty").textContent = "Current HP: " + CurrentDifficulty
}


// Forging functions
function FalseForge(){
    IsForging = false;
}

function Forge(){
    IsForging = true;

    clearTimeout(ForgeTimeout)
    ForgeTimeout = setTimeout(FalseForge, 4000)

    // Diminuir HP da forge
    CurrentDifficulty -= ClickStrength; 

    if(CurrentDifficulty <= 0){
        
        // Operações
        Electrum += WeaponGains;
        if(Energy < MaxEnergy){
            Energy += EnergyGain;
        }
        CurrentDifficulty = ClickDifficulty;

        // Mostrar nova currency e energy
        UpdateCurrency();
        
    }

    UpdateDifficulty();
}


// Soul gain functions
function ConvertEnergy(){

    if(Energy > 0 && IsForging == false){
        IsConverting = true
        Energy -= EnergyConvertRate;
        Souls += EnergyConvertRate;
        UpdateCurrency();
    }
}
let ConvertInterval = setInterval(ConvertEnergy, 3000)


// Change selected weapon
function ShowWeapons(){

    var Div = document.getElementById("Weapons");

    if(Div.style.visibility == "visible"){
        Div.style.visibility = "hidden";
    } else {
        Div.style.visibility = "visible";
    }

}

function ChangeWeapon(multi){

    ClickDifficulty = DifficultyScaling * multi;
    CurrentDifficulty = ClickDifficulty;

    if(multi != 1){
        
        WeaponGains = (multi*10)
    } else {
        WeaponGains = 1;
    }

    UpdateDifficulty();

}


// Change currency tab
function ChangeCurrency(){

    if(ElectrumTab.style.visibility !== "visible"){
        ElectrumTab.style.visibility = "visible"
        SoulTab.style.visibility = "hidden"
    } else {
        ElectrumTab.style.visibility = "hidden"
        SoulTab.style.visibility = "visible"
    }
}


// ---------------------------- Electrum Upgrades

// Click Strength upgrade
document.getElementById("UPG1Level").textContent = HammerAmount;
document.getElementById("UPG1Price").textContent = HammerPrice;
function Upgrade1(){

    if(Electrum >= HammerPrice){

        // Upgrade effect
        ClickStrength += 0.5;

        // Remover dinheiro após compra
        Electrum -= HammerPrice;

        // Quantas vezes foi comprado
        HammerAmount += 1;

        // Aumento de preço
        HammerPrice = BasePrice1*(1.15**HammerAmount);
        HammerPrice = HammerPrice.toFixed(0); // toFixed(x) apaga as casas decimais do numero

        // Atualizar elementos gráficos
        document.getElementById("UPG1Level").textContent = HammerAmount;
        document.getElementById("UPG1Price").textContent = HammerPrice;
        UpdateCurrency();
        UpdateStats()
    } else {
        
    }

}


// ---------------------------- Soul Upgrades

// Automatic forging
function AutoTower(Strength){
    
    // Diminuir HP da forge
    CurrentDifficulty -= Strength; 

    if(CurrentDifficulty <= 0){
        
        // Operações
        Electrum += WeaponGains;
        CurrentDifficulty = ClickDifficulty;

        // Mostrar nova currency e energy
        UpdateCurrency();
        
    }

    UpdateDifficulty();
    
}


// First automatic tower
document.getElementById("S_UPG1Level").textContent = Tower1_Amount;
document.getElementById("S_UPG1Price").textContent = Tower1_Price;

var Tower1_Interval = null
function Tower1(){

    if(Souls >= Tower1_Price){

        // Upgrade effect
        if(Tower1_Amount > 0){
            Tower1_Timer -= 0.2
            Tower1_RealTime = Tower1_Timer*1000

            clearInterval(Tower1_Interval)
            Tower1_Interval = setInterval(AutoTower, Tower1_RealTime, 0.5)

        } else {

            Tower1_Interval = setInterval(AutoTower, Tower1_RealTime, 0.5)

        }

        // Remover dinheiro após compra
        Souls -= Tower1_Price;

        // Quantas vezes foi comprado
        Tower1_Amount += 1;

        // Aumento de preço
        Tower1_Price = Tower1_BasePrice*(1.15**Tower1_Amount);
        Tower1_Price = Tower1_Price.toFixed(0); // toFixed(x) apaga as casas decimais do numero

        // Atualizar elementos gráficos
        document.getElementById("S_UPG1Level").textContent = Tower1_Amount;
        document.getElementById("S_UPG1Price").textContent = Tower1_Price;
        UpdateCurrency();
        UpdateStats()
    }

}
