// Weapon Difficulty and Pricing
var ClickDifficulty = 5; //HP para acabar arma
var WeaponGains = 1; //Electrum ganho ao acabar arma

// Força de click e HP atual 
var CurrentDifficulty = ClickDifficulty;
var ClickStrength = 1;

// Critical (Complete Instantly)
var Critchance = 0;

// Currency
var Electrum = 0;
var Souls = 0;

// Energy to turn into souls
var MaxEnergy = 10;
var Energy = 0;
var EnergyGain = 1;
var EnergyConvertRate = 1;

// Price and Weapon Difficulty Scaling
var PriceScaling = 1.15;
var DifficultyScaling = 5;

// Forge Check
var IsForging = false;
var ForgeTimeout

// Upgrade divisions
var ElectrumTab = document.getElementById("ElectrumDiv")
ElectrumTab.style.visibility = "visible"

var SoulTab = document.getElementById("SoulDiv")
SoulTab.style.visibility = "hidden"


// Newsboard
var News = [
    "YOO IM FLOATIN' IN HERE!!",
    "Will Will Smith smith Will Smith?",
    "Dont forget to buy demoins!",
    "I can see you",
    "这是你翻译的吗？",
    "Sword Master"
]


// ----------------- Electrum Upgrades

// First Upgrade
var BasePrice1 = 10
var HammerPrice = BasePrice1; // Preço de upgrade
var HammerAmount = 0; // Quantidade de compras (Level do upgrade)

// ----------------- Soul Upgrades

// First Upgrade
var Tower1_BasePrice = 10
var Tower1_Price = Tower1_BasePrice
var Tower1_Amount = 0

var Tower1_Timer = 5
var Tower1_RealTime = Tower1_Timer*1000