
// Weapon Difficulty and Pricing
var ClickDifficulty = 5; //HP para acabar arma
var WeaponGains = 1; //Electrum ganho ao acabar arma

// Força de click e HP atual 
var CurrentDifficulty = ClickDifficulty;
var ClickStrength = 1;

// Currency
var Electrum = 0;
var Souls = 0;

var PriceScaling = 1.15;

// Iniciar textos
document.getElementById("Difficulty").textContent = "Current HP: " + CurrentDifficulty
document.getElementById("Electrum").textContent = "Electrum: " + Electrum
document.getElementById("Souls").textContent = "Souls: " + Souls

function Forge(){
    // Diminuir HP da forge
    CurrentDifficulty -= ClickStrength; 

    document.getElementById("Difficulty").textContent = "Current HP: " + CurrentDifficulty
    if(CurrentDifficulty <= 0){
        
        // Operações
        Electrum += WeaponGains;
        CurrentDifficulty = ClickDifficulty;

        // Adicionar Currency e reiniciar HP
        document.getElementById("Difficulty").textContent = "Current HP: " + CurrentDifficulty
        document.getElementById("Electrum").textContent = "Electrum: " + Electrum

    }
    
}

var HammerPrice = 2; // Preço de upgrade
var HammerAmount = 0; // Quantidade de compras
function Upgrade(){

    if(Electrum >= HammerPrice){

        // Upgrade effect
        ClickStrength += 0.5;

        // Remover dinheiro após compra
        Electrum -= HammerPrice;

        // Quantas vezes foi comprado
        HammerAmount += 1;

        // Aumento de preço
        HammerPrice = HammerPrice*(1.15**HammerAmount);
        HammerPrice = HammerPrice.toFixed(0);

        // Atualizar elementos gráficos
        document.getElementById("UP1price").textContent = "Price: " + HammerPrice + ", amount: " + HammerAmount;
        document.getElementById("Electrum").textContent = "Electrum: " + Electrum
    } else {
        
    }

}